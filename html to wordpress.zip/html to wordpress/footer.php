<section class="footer">
    <div class="container">
        <div class="row">
            <div class="col-sm-3 wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                <div class="footer-box">
                <?php
				if(is_active_sidebar('footer-sidebar-1')){
				    dynamic_sidebar('footer-sidebar-1');
				}
			    ?>	
                </div>
            </div>

            <div class="col-sm-3 wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                <div class="footer-box">
                <?php
				if(is_active_sidebar('footer-sidebar-2')){
				    dynamic_sidebar('footer-sidebar-2');
				}
			?>
                </div>
            </div>

            <div class="col-sm-3 wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                <div class="footer-box">
                <?php
				if(is_active_sidebar('footer-sidebar-3')){
				    dynamic_sidebar('footer-sidebar-3');
				}
			?>
                </div>
            </div>

            <div class="col-sm-3 wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                <div class="footer-box">
                <?php
				if(is_active_sidebar('footer-sidebar-4')){
				    dynamic_sidebar('footer-sidebar-4');
				}
			    ?>
                </div>
            </div>	
        </div>
            <hr>
            <div class="row" id="con-foot">
            <div class="col-md-3 col-sm-3 wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                <div class="footer-box">
                    <div class="footer-heading">
                        <h3>Contact Us</h3>
                    </div>
                    <div class="footer-content">
                        <ul>
                            <li><i class="fa fa-map-marker"></i><span>EL 86, TTC Industrial Estate, MIDC<br> Mahape, Navi Mumbai,<br> Maharashtra, India – 400701</span></li>
                            <li><i class="fa fa-phone"></i> <span><a href="tel:9321333022"></a><a href="tel:9321333022">Maharashtra: +91 932-133-3022</a><br>  <a href="tel:9448286758">Karnataka: +91 944-828-6758<br></a> <a href="tel:9909041808">Gujarat: +91 990-904-1808</a></span></li>
                            <li><i class="fa fa-envelope"></i> <span><a href="mailto:support@saral-health.com">support@saral-health.com</a></span></li>
                        </ul>
                    </div>
                </div>
            </div>
            
                    <div class="col-md-5 col-sm-6">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3769.9909810596646!2d73.02438081496291!3d19.10805158706952!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c0e51ce22575%3A0xc9060ba331d4a81d!2sSaral+Vaastu!5e0!3m2!1sen!2sin!4v1514889038523" width="100%" height="300" frameborder="0" style="border:0" allowfullscreen=""></iframe>
                    </div>
                <div class="col-md-4 col-sm-6 wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;">
                <div class="footer-box">
                    <div class="footer-heading">
                        <h3>SUBSCRIBE OUR NEWSLETTER</h3>
                    </div>
                    <div class="footer-content">
                        <form action="./thank-you" class="form-horizontal" method="post" name="form1" onsubmit="return validateForm()">
                            <div class="form-group">
                                <input type="text" class="form-control" placeholder="Your Name *" name="fullname" id="fullname" required="">
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control" placeholder="Email Id *" name="email" id="email" required="" pattern="[a-zA-Z0-9.-_]{1,}@[a-zA-Z.-]{2,}[.]{1}[a-zA-Z]{2,}" title="Email Id (Format: xxx@xxx.xxx)">
                                    <input class="fields" name="callForm" type="hidden" value="newsletter" id="callForm">
                            </div>
                            <div class="form-group">
                                <button type="submit" class="viewall-btn">Submit</button>
                            </div>
                            </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>