<!DOCTYPE html>
<html <?php language_attributes(); ?> class="no-js no-svg">
<head>   
   <link rel="shortcut icon" href="<?php echo get_template_directory_uri(); ?>/img/favicon.png" />
   <meta charset="<?php bloginfo( 'charset' ); ?>">
   <meta name="viewport" content="width=device-width, initial-scale=1">
   <link rel="profile" href="http://gmpg.org/xfn/11">

   <?php wp_head(); ?>
   <!--- Social Share Buttons -->
   <script src="https://static.addtoany.com/menu/page.js"></script>
	<script>
      var current_url = window.location.href;
      //	alert(current_url);
   </script>
   <!-- Analytics code added -->
   <!-- Global site tag (gtag.js) - Google Analytics -->
   <script src="https://www.googletagmanager.com/gtag/js?id=UA-128598459-1"></script>
   <script>
      window.dataLayer = window.dataLayer || [];
      function gtag(){dataLayer.push(arguments);}
      gtag('js', new Date());
      gtag('config', 'UA-128598459-1');
   </script>
   <!-- end -->

   </head>

<body <?php body_class(); ?>>
<div class="sticky">
<div class="header-top">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="top-call pull-left">
                    <ul>
                        <li>Follow Us:</li>
                        <li>
                            <a href="https://www.facebook.com/SaralHealthy/" target="_blank">
                                <i class="fa fa-facebook-square" aria-hidden="true"></i>
                            </a>
                        </li>
                            
                        <li>
                            <a href="https://twitter.com/SaralHealthy" target="_blank">
                                <i class="fa fa-twitter-square" aria-hidden="true"></i>
                            </a>
                        </li>
                            
                        <li>
                            <a href="https://www.instagram.com/saral_health/" target="_blank">
                                <i class="fa fa-instagram" aria-hidden="true"></i>
                            </a>
                        </li>
                            
                        <li>
                            <a href="https://www.youtube.com/c/SaralHealth" target="_blank">
                                <i class="fa fa-youtube" aria-hidden="true"></i>
                            </a>
                        </li>
                                                        <li>Call Us :
                            <a href="tel:9321333022">+91 9321-333-022</a>
                        </li>
                    </ul>
                </div>
                    <div class="call"><ul class="header-top-call pull-right"><li class="dekstop-hide-con"><a href="tel:{{{setting.mobile_number.call}}}">Contact <i class="fa fa-phone"></i></a></li><li class="dekstop-show-con"><a href="#con-foot">Contact <i class="fa fa-phone"></i></a></li><li><a href="#con-foot">Subscribe <i class="fa fa-pencil" aria-hidden="true"></i></a></li><li><a href="./our-center">Centers <i class="fa fa-map-marker" aria-hidden="true"></i></a></li></ul></div> 

            </div>
        </div>
    </div>
</div>
<header class="header transparent_nav">
    <div class="container">
        <div class="row">
            <div class="col-md-3 col-sm-6 col-xs-12">
                <a href="../" class="logo hidden-md hidden-lg hidden-sm">
                    <img src="https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/Saral+Energy+for+Health.png"> </a>
                <a href="../" class="logo hidden-xs">
                    <img src="https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/Saral+Energy+for+Health.png"> </a>
            </div>
            <div class="rspnav">
                <nav class="collnav collapse">
                <?php
                    $defaults = array(
                        'theme_location' => 'top', 
                        'container' => '', 
                        'menu_class' => '', 
                        'menu' => 'top_menu'
                    );
                    wp_nav_menu($defaults); 
					?>		
                </nav>
            </div>
            <div class="col-md-1 col-sm-6 col-xs-4">
                <div class="hidden-lg hidden-md pull-right rspbtn">
                    <button data-toggle="collapse" data-target=".collnav">
                        <i class="fa fa-bars"></i>
                    </button>
                </div>
            </div>
        </div>
    </div>
</header>
</div>