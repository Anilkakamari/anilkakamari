<?php 
function add_theme_scripts() {
   
  wp_enqueue_style( 'bootstrap', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css', array(), '3.3.7', 'all');
  wp_enqueue_style( 'font-awesome' , 'https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css', array(),'4.7.0', 'all');
  wp_enqueue_style( 'slick-css', get_template_directory_uri() . 'https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/style/slick.css', array (), 1.0, 'all');
  wp_enqueue_style( 'slick-theme-css', get_template_directory_uri() . 'https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/style/slick-theme.css', array (), 1.0, 'all');
  wp_enqueue_style( 'menu-css', get_template_directory_uri() . '/css/menu.css', array (), 1.0, 'all');
  wp_enqueue_style( 'style', get_stylesheet_uri() );  
  wp_enqueue_style( 'custom-wp-css', get_template_directory_uri() . '/css/custom-wp.css', array (), 1.0, 'all');
  wp_enqueue_style( 'healthnew', get_template_directory_uri() . 'https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/style/healthnew.css', array (), 1.0, 'all');
  wp_enqueue_style( 'font-awsome', get_template_directory_uri() . 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css', array (), 1.0, 'all');
  wp_enqueue_style( 'animation', get_template_directory_uri() . 'https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/style/animate.css', array (), 1.0, 'all');
  wp_enqueue_style( 'carousel', get_template_directory_uri() . 'https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/style/owl.carousel.min.css', array (), 1.0, 'all');
  wp_enqueue_style( 'carousel', get_template_directory_uri() . 'https://d2w521bwxk3ets.cloudfront.net/assets/images/shvastu/style/owl.theme.default.min.css', array (), 1.0, 'all');
  
  
  wp_enqueue_script( 'jquery', 'https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js', array (), 1.1, true);
  wp_enqueue_script( 'bootstrap-min', 'https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js', array (), 1.1, true);
  wp_enqueue_script( 'menu-js', get_template_directory_uri() . '/js/menu.js', array (), 1.0, true);
  wp_enqueue_script( 'script', get_template_directory_uri() . '/js/script.js', array (), 1.0, true);
  wp_enqueue_script( 'slick-min', get_template_directory_uri() . '/css/slick/slick.min.js', array (), 1.0, true);
}

add_action( 'wp_enqueue_scripts', 'add_theme_scripts' );


add_theme_support( 'menus' );
add_theme_support( 'title-tag' );

function footer_widget_init() {
	register_sidebar( array(
	'name' => 'Footer Sidebar 1',
	'id' => 'footer-sidebar-1',
	'description' => 'Appears in the footer area',
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h4 class="h-widget">',
	'after_title' => '</h4>',
	) );
	register_sidebar( array(
	'name' => 'Footer Sidebar 2',
	'id' => 'footer-sidebar-2',
	'description' => 'Appears in the footer area',
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h4 class="h-widget">',
	'after_title' => '</h4>',
	) );
	register_sidebar( array(
	'name' => 'Footer Sidebar 3',
	'id' => 'footer-sidebar-3',
	'description' => 'Appears in the footer area',
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h4 class="h-widget">',
	'after_title' => '</h4>',
	) );
	register_sidebar( array(
	'name' => 'Footer Sidebar 4',
	'id' => 'footer-sidebar-4',
	'description' => 'Appears in the footer area',
	'before_widget' => '<aside id="%1$s" class="widget %2$s">',
	'after_widget' => '</aside>',
	'before_title' => '<h4 class="h-widget">',
	'after_title' => '</h4>',
	) );

}
add_action( 'widgets_init', 'footer_widget_init' );

// Let us create Taxonomy for Custom Post Type
add_action( 'init', 'create_taxonomy_testimonials_types', 0 );
 
//create a custom taxonomy name it "type" for your posts
function create_taxonomy_testimonials_types() {
 
  $labels = array(
    'name' => _x( 'Types', 'taxonomy general name' ),
    'singular_name' => _x( 'Type', 'taxonomy singular name' ),
    'search_items' =>  __( 'Search Types' ),
    'all_items' => __( 'All Types' ),
    'parent_item' => __( 'Parent Type' ),
    'parent_item_colon' => __( 'Parent Type:' ),
    'edit_item' => __( 'Edit Type' ), 
    'update_item' => __( 'Update Type' ),
    'add_new_item' => __( 'Add New Type' ),
    'new_item_name' => __( 'New Type Name' ),
    'menu_name' => __( 'Types' ),
  ); 	
 
  register_taxonomy('types',array('testimonials'), array(
    'hierarchical' => true,
    'labels' => $labels,
    'show_ui' => true,
    'show_admin_column' => true,
    'query_var' => true,
    'rewrite' => array( 'slug' => 'type' ),
  ));
}


if (!is_admin()) add_action("wp_enqueue_scripts", "my_jquery_enqueue", 11);
function my_jquery_enqueue() {
   wp_deregister_script('jquery');
   wp_register_script('jquery', "//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js", false, null);
   wp_enqueue_script('jquery');
}





// add custom field for color/background color of testimonials  
function testimonial_types_taxonomy_custom_fields($tag) {  
   // Check for existing taxonomy meta for the term you're editing  
    $t_id = $tag->term_id; // Get the ID of the term you're editing  
    $term_meta = get_option( "taxonomy_term_$t_id" ); // Do the check  
?>  
  
<tr class="form-field">  
    <th scope="row" valign="top">  
        <label for="testimonial_type_color"><?php _e('Testimonial Type Color'); ?></label>  
    </th>  
    <td>  
        <input type="text" name="term_meta[testimonial_type_color]" id="term_meta[testimonial_type_color]" size="25" style="width:60%;" value="<?php echo $term_meta['testimonial_type_color'] ? $term_meta['testimonial_type_color'] : ''; ?>"><br />  
        <span class="description"><?php _e('The testimonial type will be shown with same color'); ?></span>  
    </td>  
</tr>  
  
<?php  
}

// A callback function to save our extra taxonomy field(s)  
function save_taxonomy_custom_fields( $term_id ) {  
    if ( isset( $_POST['term_meta'] ) ) {  
        $t_id = $term_id;  
        $term_meta = get_option( "taxonomy_term_$t_id" );  
        $cat_keys = array_keys( $_POST['term_meta'] );  
            foreach ( $cat_keys as $key ){  
            if ( isset( $_POST['term_meta'][$key] ) ){  
                $term_meta[$key] = $_POST['term_meta'][$key];  
            }  
        }  
        //save the option array  
        update_option( "taxonomy_term_$t_id", $term_meta );  
    }  
}

// Add the fields to the "presenters" taxonomy, using our callback function  
add_action( 'types_add_form_fields', 'testimonial_types_taxonomy_custom_fields', 10, 2 );  
add_action( 'types_edit_form_fields', 'testimonial_types_taxonomy_custom_fields', 10, 2 );  
  
// Save the changes made on the "presenters" taxonomy, using our callback function
add_action( 'create_types', 'save_taxonomy_custom_fields', 10, 2 );  
add_action( 'edited_types', 'save_taxonomy_custom_fields', 10, 2 );  






function wcr_category_fields($term) {
    // we check the name of the action because we need to have different output
    // if you have other taxonomy name, replace category with the name of your taxonomy. ex: book_add_form_fields, book_edit_form_fields
    if (current_filter() == 'category_edit_form_fields') {
        $color_code = get_term_meta($term->term_id, 'color_code', true);
        ?>        
        <tr class="form-field">
            <th valign="top" scope="row"><label for="term_fields[color_code]"><?php _e('Color'); ?></label></th>
            <td>
                <input type="text" size="40" value="<?php echo esc_attr($color_code); ?>" id="term_fields[color_code]" name="term_fields[color_code]"><br/>
                <span class="description"><?php _e('Please enter color'); ?></span>
            </td>
        </tr>   
	<?php
    }
}

// Add the fields, using our callback function  
// if you have other taxonomy name, replace category with the name of your taxonomy. ex: book_add_form_fields, book_edit_form_fields
add_action('category_add_form_fields', 'wcr_category_fields', 10, 2);
add_action('category_edit_form_fields', 'wcr_category_fields', 10, 2);

function wcr_save_category_fields($term_id) {
    if (!isset($_POST['term_fields'])) {
        return;
    }

    foreach ($_POST['term_fields'] as $key => $value) {
        update_term_meta($term_id, $key, sanitize_text_field($value));
    }
}

// Save the fields values, using our callback function
// if you have other taxonomy name, replace category with the name of your taxonomy. ex: edited_book, create_book
add_action('edited_category', 'wcr_save_category_fields', 10, 2);
add_action('create_category', 'wcr_save_category_fields', 10, 2);





/*add the option to add logo dyanmically for desktop and mobile*/
function m1_customize_register( $wp_customize ) {
    $wp_customize->add_setting( 'm1_logo' ); // Add setting for logo uploader
    
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'm1_logo', array(
        'label'    => __( 'Desktop Site logo', 'm1' ),
        'section'  => 'title_tagline',
        'settings' => 'm1_logo',
    ) ) );
	
}
add_action( 'customize_register', 'm1_customize_register' );

function m2_customize_register( $wp_customize ) {
    $wp_customize->add_setting( 'm2_logo' ); // Add setting for logo uploader
    
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'm2_logo', array(
        'label'    => __( 'Mobile site logo', 'm2' ),
        'section'  => 'title_tagline',
        'settings' => 'm2_logo',
    ) ) );
	
}
add_action( 'customize_register', 'm2_customize_register' );
/*code ended*/

function headerbanner_customize_register( $wp_customize ) {
    $wp_customize->add_setting( 'headerbanner' ); // Add setting for logo uploader
    
    $wp_customize->add_control( new WP_Customize_Image_Control( $wp_customize, 'headerbanner', array(
        'label'    => __( 'Header Banner', 'headerbanner' ),
        'section'  => 'title_tagline',
        'settings' => 'headerbanner',
    ) ) );
	
}
add_action( 'customize_register', 'headerbanner_customize_register' );
/*code ended*/

function add_featured_image() {
    add_theme_support( 'post-thumbnails');
}
add_action( 'after_setup_theme', 'add_featured_image' );


?>